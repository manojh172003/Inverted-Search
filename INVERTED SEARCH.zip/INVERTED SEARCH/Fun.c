#include "head.h"

int is_duplicate(char *filename, file_list *head)
{
    file_list *temp = head;
    while (temp)
    {
        if (strcmp(temp->filename, filename) == 0)
            return 1;
        temp = temp->link;
    }
    return 0;
}

void insert_file(char *filename, file_list **head)
{
    file_list *new = malloc(sizeof(file_list));
    strcpy(new->filename, filename);
    new->link = NULL; // this will be the last node

    if (*head == NULL) // empty list
    {
        *head = new;
        return;
    }

    // traverse to the end of the list
    file_list *temp = *head;
    while (temp->link != NULL)
        temp = temp->link;

    temp->link = new; // append at end
}

// Free all dynamically allocated memory
void free_all(Hash_table *Hash_arr, file_list *file)
{
    if (Hash_arr == NULL)
        return;

    for (int i = 0; i < 27; i++)
    {
        Main_Node *m = Hash_arr[i].main_link;
        while (m != NULL)
        {
            Sub_Node *s = m->sub_link;
            while (s != NULL)
            {
                Sub_Node *tmp_s = s;
                s = s->sub_link;
                free(tmp_s);
            }

            Main_Node *tmp_m = m;
            m = m->main_link;
            free(tmp_m);
        }
        Hash_arr[i].main_link = NULL;
    }

    while (file != NULL)
    {
        file_list *tmp = file;
        file = file->link;
        free(tmp);
    }
}
