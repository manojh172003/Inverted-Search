

#include "head.h"

void Display(Hash_table *Hash_arr)
{
    int flag = 0;

    for (int j = 0; j < 27; j++)
    {
        if (Hash_arr[j].main_link != NULL)
        {
            flag = 1;
            break;
        }
    }

    if (flag == 0)
    {
        printf("Database is empty\n");
        return;
    }

    /* Header */
    printf("\n%-5s %-13s %-13s %s\n",
           "Idx", "Word", "Files", "FileName : Count");
    printf("-------------------------------------------------------------\n");

    for (int i = 0; i < 27; i++)
    {
        if (Hash_arr[i].main_link == NULL)
            continue;

        Main_Node *Main_temp = Hash_arr[i].main_link;

        while (Main_temp != NULL)
        {
            /* Print index, word, file count */
            printf("%-5d %-15s %-10d ",
                   i,
                   Main_temp->word,
                   Main_temp->file_count);

            /* Print all sub-nodes on same line */
            Sub_Node *Sub_temp = Main_temp->sub_link;
            while (Sub_temp != NULL)
            {
                printf("%s : %-3d  ",
                       Sub_temp->file_Name,
                       Sub_temp->word_count);

                Sub_temp = Sub_temp->sub_link;
            }

            printf("\n");
            Main_temp = Main_temp->main_link;
        }
    }

    printf("-------------------------------------------------------------\n\n");
}
