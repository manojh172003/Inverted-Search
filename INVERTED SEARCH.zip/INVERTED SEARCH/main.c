/*
*********************************************************
Name : MANOJ H
Description : This inverted search project uses a hash table with linked lists to store and manage the inverted index efficiently.
Each keyword is hashed to a bucket, where a linked list maintains references to all documents containing that word.
Date : 15 MARCH 2026 - 20 MARCH 2026
*/

#include "head.h"

int main(int argc, char *argv[])
{
    file_list *file = NULL; //  created in MAIN

    if (argc <= 1)
    {
        printf("Usage: ./a.out file1.txt file2.txt ...\n");
        return Failure;
    }

    for (int i = 1; i < argc; i++)
    {
        char *filename = argv[i];

        // 1. Check extension
        char *dot = strrchr(filename, '.');
        if (dot == NULL || strcmp(dot, ".txt") != 0)
        {
            printf("Error: '%s' must be a .txt file.\n", filename);
            return Failure;
        }

        // 2. Duplicate check using list inside main
        if (is_duplicate(filename, file))
        {
            printf("Error: Duplicate file '%s'.\n", filename);
            return Failure;
        }

        // 3. Check file exists
        FILE *fp = fopen(filename, "r");
        if (!fp)
        {
            printf("Error: Cannot open file '%s'.\n", filename);
            return Failure;
        }

        // 4. Check empty file
        fseek(fp, 0, SEEK_END);
        long size = ftell(fp);
        fclose(fp);

        if (size == 0)
        {
            printf("Error: File '%s' is EMPTY.\n", filename);
            return Failure;
        }

        // 5. Insert file into the linked list
        insert_file(filename, &file);
    }
    int option = 1, res;
    int index = 27;

    Hash_table Hash_arr[index];
    for (int i = 0; i < index; i++)
    {
        Hash_arr[i].index = i;
        Hash_arr[i].main_link = NULL;
    }

    int c_flag = 0, u_flag = 0;
    while (1)
    {
        /* code */
        printf("::::MENU::::\n");
        printf("1.Create DB\n2.Search DB\n3.Display DB\n4.Update DB\n5.Save\n6.Exit\n");
        printf("Enter Option : ");
        scanf("%d", &option);

        switch (option)
        {
        case 1:
            /* code */
            if (c_flag == 0 && u_flag == 0)
            {
                res = Create_DB(Hash_arr, file);
                c_flag = 1;
            }
            else
            {
                if (u_flag == 1)
                    printf("After Update Create can't be used\n");
                if (c_flag == 1)
                    printf("Create can be used only once\n");
            }

            break;
        case 2:
            Search(Hash_arr);
            break;
        case 3:
            Display(Hash_arr);
            break;
        case 4:
            if (c_flag == 1 || u_flag == 1)
            {
                printf("Update Failed\n");
            }
            else
            {
                // update function
                char fname[50];
                printf("Enter backup file name: ");
                scanf("%49s", fname);

                int res = update_db(Hash_arr, fname, &file);
                if (res == Success)
                {
                    printf("Database updated successfully from '%s'.\n", fname);
                    u_flag = 1;
                }
                else
                {
                    printf("Update failed. Check the file name or file format.\n");
                }
            }
            break;
        case 5:
            save_to_file(Hash_arr);
            break;
        case 6:

            if (c_flag == 1 || u_flag == 1)
                free_all(Hash_arr, file);
            else
                free_all(NULL, file);

            printf("Exiting...\n");
            exit(0);
            break;

        default:
            break;
        }
    }

    return Success;
}