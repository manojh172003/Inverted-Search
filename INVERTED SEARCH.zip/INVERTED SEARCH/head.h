#ifndef HEAD_H
#define HEAD_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct node
{
    /* data */
    char filename[20];
    struct node *link;
} file_list;

typedef struct Sub
{
    char file_Name[20];
    int word_count;
    struct Sub *sub_link;
} Sub_Node;

typedef struct Main
{
    char word[20];
    int file_count;
    Sub_Node *sub_link;
    struct Main *main_link;

} Main_Node;

typedef struct Hash
{
    int index;
    Main_Node *main_link;
} Hash_table;

enum
{
    Success,
    Failure,
    Empty,
    Found,
    Not_found
};

int is_duplicate(char *filename, file_list *head);
void insert_file(char *filename, file_list **head);
void Display(Hash_table *Hash_arr);
int Create_DB(Hash_table *Hash_arr, file_list *file);
int store_word(char *word, file_list *file, Hash_table *hash_arr);
void Search(Hash_table *Hash_arr);
void free_all(Hash_table *Hash_arr, file_list *file);
void save_to_file(Hash_table *Hash_arr);
int update_db(Hash_table *Hash_arr, const char *filename, file_list **file_list_head);
#endif // HEAD_H
