#include "head.h"

void Search(Hash_table *Hash_arr)
{
    char *word;
    printf("Enter the world\n");
    scanf("%s", word);
    // printf("word -- > %s\n",word);
    int index;
    if (isalpha(word[0]))
        index = tolower(word[0]) - 'a';
    else
        index = 26;

    Main_Node *temp = Hash_arr[index].main_link;
    while (temp)
    {
        if (strcmp(word, temp->word))
        {
            printf("%-5d %-15s %-10d ",
                   index,
                   temp->word,
                   temp->file_count);

            /* Print all sub-nodes on same line */
            Sub_Node *Sub_temp = temp->sub_link;
            while (Sub_temp != NULL)
            {
                printf("%s : %-3d  ",
                       Sub_temp->file_Name,
                       Sub_temp->word_count);

                Sub_temp = Sub_temp->sub_link;
            }
            printf("\n");
            return;
        }
        temp = temp->main_link;
    }

    if (temp == NULL)
    {
        printf("Word Not found\n");
        return;
    }
}
