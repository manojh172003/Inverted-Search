#include "head.h"
int update_db(Hash_table *Hash_arr, const char *filename, file_list **file_list_head)
{
    FILE *fp = fopen(filename, "r");
    if (!fp)
    {
        printf("Cannot open file '%s'\n", filename);
        return Failure;
    }

    char line[1024];

    while (fgets(line, sizeof(line), fp))
    {
        if (line[0] != '#')
            continue;

        char *ptr = line + 1;

        int index, file_count;
        char word[100];

        if (sscanf(ptr, " %d ; %99[^;] ; %d ;", &index, word, &file_count) != 3)
            continue;

        // move ptr past main node info
        char *sub_ptr = ptr;
        for (int i = 0; i < 3; i++)
        {
            sub_ptr = strchr(sub_ptr, ';');
            if (!sub_ptr)
                break;
            sub_ptr++;
        }
        if (!sub_ptr)
            continue;

        char *p = sub_ptr;
        for (int i = 0; i < file_count; i++)
        {
            char fname[100];
            int wcount;

            if (sscanf(p, " %99[^;] ; %d ;", fname, &wcount) != 2)
                break;

            // Find file in file list
            file_list *fptr = *file_list_head;
            file_list *last = NULL;

            while (fptr && strcmp(fptr->filename, fname) != 0)
            {
                last = fptr;
                fptr = fptr->link;
            }

            if (!fptr)
            {
                // File not found → create and append
                insert_file(fname, file_list_head);

                // Get the newly inserted file (at the end)
                fptr = *file_list_head;
                while (fptr->link)
                    fptr = fptr->link;
            }

            // Insert word wcount times
            for (int j = 0; j < wcount; j++)
                store_word(word, fptr, Hash_arr);

            // Move to next subnode
            p = strchr(p, ';'); // skip filename ;
            if (!p)
                break;
            p++;
            p = strchr(p, ';'); // skip word count ;
            if (!p)
                break;
            p++;
        }
    }

    fclose(fp);
    return Success;
}
