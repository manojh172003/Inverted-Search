


#include "head.h"
int store_word(char *word, file_list *file, Hash_table *hash_arr)
{
    int index;

    /* Determine hash index (0–25 for A–Z, 26 for others) */
    if (isalpha(word[0]))
        index = tolower(word[0]) - 'a';
    else
        index = 26;

    Main_Node *temp = hash_arr[index].main_link;
    Main_Node *prev = NULL;

    /* =======================================================
       CASE 1: This bucket is empty → store the first word
       ======================================================= */
    if (temp == NULL)
    {
        Main_Node *Main_temp = malloc(sizeof(Main_Node));
        if (!Main_temp)
        {
            printf("Main node creation failed\n");
            return Failure;
        }

        strcpy(Main_temp->word, word);
        Main_temp->file_count = 1;
        Main_temp->main_link = NULL;

        /* Create first subnode (file & count info) */
        Sub_Node *Sub_temp = malloc(sizeof(Sub_Node));
        if (!Sub_temp)
        {
            printf("Sub node creation failed\n");
            return Failure;
        }

        strcpy(Sub_temp->file_Name, file->filename);
        Sub_temp->word_count = 1;
        Sub_temp->sub_link = NULL;

        Main_temp->sub_link = Sub_temp;

        /* Insert into hash table */
        hash_arr[index].main_link = Main_temp;

        return Success;
    }

    /* =======================================================
       CASE 2: Bucket not empty → search for the word
       ======================================================= */
    while (temp != NULL)
    {
        /* Word already exists in this bucket */
        if (strcmp(temp->word, word) == 0)
        {
            Sub_Node *s = temp->sub_link;
            Sub_Node *s_prev = NULL;

            /* Search subnodes to check if file already exists */
            while (s != NULL)
            {
                if (strcmp(s->file_Name, file->filename) == 0)
                {
                    /* This file already has this word → increment count */
                    s->word_count++;
                    return Success;
                }
                s_prev = s;
                s = s->sub_link;
            }

            /* File not found → create a new subnode at END (no sorting) */
            Sub_Node *new_sub = malloc(sizeof(Sub_Node));
            if (!new_sub)
            {
                printf("Sub node creation failed\n");
                return Failure;
            }

            strcpy(new_sub->file_Name, file->filename);
            new_sub->word_count = 1;
            new_sub->sub_link = NULL;

            /* Append new subnode in preserved order */
            s_prev->sub_link = new_sub;

            /* Increase number of files containing this word */
            temp->file_count++;

            return Success;
        }

        /* Continue searching in main list */
        prev = temp;
        temp = temp->main_link;
    }

    /* =======================================================
       CASE 3: Word NOT found → insert new Main_Node at END
       ======================================================= */
    Main_Node *Main_temp = malloc(sizeof(Main_Node));
    if (!Main_temp)
    {
        printf("Main node creation failed\n");
        return Failure;
    }

    strcpy(Main_temp->word, word);
    Main_temp->file_count = 1;
    Main_temp->main_link = NULL;

    /* Create the first subnode for this new word */
    Sub_Node *Sub_temp = malloc(sizeof(Sub_Node));
    if (!Sub_temp)
    {
        printf("Sub node creation failed\n");
        return Failure;
    }

    strcpy(Sub_temp->file_Name, file->filename);
    Sub_temp->word_count = 1;
    Sub_temp->sub_link = NULL;

    Main_temp->sub_link = Sub_temp;

    /* Append new main node at END of list (IMPORTANT!!!) */
    prev->main_link = Main_temp;

    return Success;
}
