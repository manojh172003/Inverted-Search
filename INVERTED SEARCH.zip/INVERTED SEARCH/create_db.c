#include "head.h"

int Create_DB(Hash_table *Hash_arr, file_list *file)
{
    while (file != NULL)
    {
        FILE *fptr = fopen(file->filename, "r");
        if (fptr == NULL)
        {
            printf("File Not Opened\n");
            return Failure;
        }

        char word[50];
        while (fscanf(fptr, "%s", word) == 1)
        {

            if (store_word(word, file, Hash_arr) == Failure) // Store each word in database.
            {
                printf("Storing word to database failed\n"); // Error if storage fails.
                fclose(fptr);                                // Close file before returning.
                return Failure;
            }
        }

        fclose(fptr);
        file = file->link;
        }

    printf("Data Base Created\n");
    return Success;
}