#include "head.h"

void save_to_file(Hash_table *Hash_arr)
{
    int empty = 1;
    for (int i = 0; i < 27; i++)
    {
        if (Hash_arr[i].main_link != NULL)
        {
            empty = 0;
            break;
        }
    }

    if (empty)
    {
        printf("Database is empty\n");
        return;
    }

    char filename[100];
    printf("Enter the .txt file to store: ");
    scanf("%99s", filename);

    // Check .txt extension
    char *dot = strrchr(filename, '.');
    if (!dot || strcmp(dot, ".txt") != 0)
    {
        printf("Error: '%s' must be a .txt file.\n", filename);
        return;
    }

    FILE *fp = fopen(filename, "w");
    if (!fp)
    {
        printf("Cannot open file '%s' for writing\n", filename);
        return;
    }

    // Traverse hash table
    for (int i = 0; i < 27; i++)
    {
        Main_Node *m = Hash_arr[i].main_link;
        while (m)
        {
            fprintf(fp, "#%d ; %s ; %d ;", i, m->word, m->file_count);

            Sub_Node *s = m->sub_link;
            while (s)
            {
                fprintf(fp, "%s ; %d ;", s->file_Name, s->word_count);
                s = s->sub_link;
            }

            fprintf(fp, "#\n");
            m = m->main_link;
        }
    }

    fclose(fp);
    printf("Database saved successfully to '%s'\n", filename);
}
